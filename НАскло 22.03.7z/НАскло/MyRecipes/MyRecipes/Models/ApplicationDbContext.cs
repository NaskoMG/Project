﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyRecipes.Models
{
    public class ApplicationDbContext:DbContext
    {

        public ApplicationDbContext(DbContextOption<ApplicationDbContext> options) : base (options)
        {
            this.DataBase.Migrate();
            public DbSet<Client> Client { get; set; }
             public DbSet<Product> Product { get; set; }
            public DbSet<Order> Order { get; set; }
    }
      
}
