﻿namespace MyRecipes.Models
{
    public class DbContext
    {
    }
}