﻿namespace MyRecipes.Models
{
    internal class ctor
    {
    }
}